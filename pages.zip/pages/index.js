import { motion } from "framer-motion";
import styles from "../styles/Home.module.css";
import Carousel from "../components/carousel";
import WhatsAppButton from "../components/WhatsAppButton";
import useScrollFade from "../components/useScrollFade";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faProjectDiagram,
  faCubes,
  faCalculator,
  faChalkboardTeacher,
} from "@fortawesome/free-solid-svg-icons";

export default function Home() {
  useScrollFade();

  return (
    <div>
      {/* ====== HERO SECTION ====== */}
      <motion.header
        className={`${styles.hero} fadeInSection`}
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>Innovación en Arquitectura e Ingeniería</h1>
          <motion.p
            className={styles.heroSubtitle}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.3 }}
          >
            Transformamos ideas en proyectos sólidos y sostenibles.
          </motion.p>
          <motion.button
            className={styles.button}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            onClick={() => {
              document
                .getElementById("about-section")
                ?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            LEER MÁS
          </motion.button>
        </div>
      </motion.header>

      {/* ====== INFO SECTION: ACERCA DE NOSOTROS ====== */}
      <section className={`${styles.infoSection} fadeInSection`} id="about-section">
        <div className={styles.infoContainer}>
          <h2 className={styles.tiltedTitle}>
            <span>¿QUIÉNES SOMOS?</span>
          </h2>
          <p>
            Somos una empresa comprometida con la excelencia en la asesoría y el 
            desarrollo de proyectos en arquitectura e ingeniería civil. Nuestro equipo 
            de profesionales trabaja con pasión para ofrecer soluciones integrales y 
            sustentables.
          </p>
        </div>
        <div className={styles.infoImage}>
          <img src="/prueba3.jpg" alt="Acerca de Nosotros" />
        </div>
      </section>

      {/* ====== MISIÓN Y VISIÓN ====== */}
      <section className={`${styles.misionVisionCircles} fadeInSection`}>
        <div className={styles.misionVisionTitle}>Misión & Visión</div>
        <div className={styles.circle}>
          <h2>Misión</h2>
          <p>
            Proporcionar soluciones académicas personalizadas para estudiantes de
            arquitectura e ingeniería civil, garantizando excelencia y calidad en
            cada asesoría.
          </p>
        </div>
        <div className={styles.circleLogo}>
          <img src="/logo3.png" alt="Logo" />
        </div>
        <div className={styles.circle}>
          <h2>Visión</h2>
          <p>
            Ser la empresa líder en asistencia académica para arquitectura e
            ingeniería civil, destacándonos por nuestra calidad, profesionalismo y
            compromiso con el éxito de nuestros clientes.
          </p>
        </div>
      </section>

      {/* ====== "¿TE AYUDAMOS?" + CARRUSEL ====== */}
      <div className={`${styles.carouselContainer} fadeInSection`}>
        <div className={styles.helpTitleContainer}>
          <h2 className={styles.helpTitle}>¿Te ayudamos?</h2>
        </div>
        <Carousel />
      </div>

      {/* ====== BOTÓN DE WHATSAPP FLOTANTE ====== */}
      <WhatsAppButton />

      {/* ====== SERVICIOS ====== */}
      <section className={`${styles.servicesSection} fadeInSection`}>
        <div className={styles.servicesContainer}>
          <div className={styles.servicesHeader}>
            <h2 className={styles.sectionTitle}>Nuestros Servicios</h2>
            <motion.button
              className={styles.servicesButton}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                window.location.href = "/servicios";
              }}
            >
              Ver más
            </motion.button>
          </div>
          <p className={styles.sectionSubtitle}>
            Ofrecemos soluciones integrales en arquitectura e ingeniería civil.
          </p>
          <div className={styles.cardsWrapper}>
            {[
              {
                icon: faProjectDiagram,
                title: "Asesoría en proyectos",
                text: "Guiamos y desarrollamos proyectos académicos y profesionales en arquitectura e ingeniería.",
              },
              {
                icon: faCubes,
                title: "Modelado y representación digital",
                text: "Creación de planos, renders y modelos 3D para proyectos académicos y profesionales.",
              },
              {
                icon: faCalculator,
                title: "Cálculo estructural",
                text: "Asesoramiento en diseño estructural y análisis de resistencia de materiales.",
              },
              {
                icon: faChalkboardTeacher,
                title: "Capacitaciones y tutorías",
                text: "Clases especializadas en software de arquitectura, ingeniería y construcción.",
              },
            ].map((service, index) => (
              <motion.article
                key={index}
                className={styles.card}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                <FontAwesomeIcon icon={service.icon} className={styles.icon} />
                <h3>{service.title}</h3>
                <p>{service.text}</p>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      {/* ====== CONTACTO / CTA ====== */}
      <section className={`${styles.contactSection} fadeInSection`}>
        <div className={styles.contactContainer}>
          <h2>¿Listo para comenzar tu proyecto?</h2>
          <p>
            Ponte en contacto con nosotros para una asesoría personalizada y descubre
            cómo podemos ayudarte a llevar tu idea al siguiente nivel.
          </p>
          <motion.button
            className={styles.contactButton}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              window.location.href = "/contacto";
            }}
          >
            Contáctanos
          </motion.button>
        </div>
      </section>
    </div>
  );
}
