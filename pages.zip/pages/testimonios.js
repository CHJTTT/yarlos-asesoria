const Testimonios = () => {
    return (
      <div>
        <h1>Testimonios</h1>
        <p>Lee lo que dicen nuestros clientes.</p>
      </div>
    );
  };
  
  export default Testimonios;
  